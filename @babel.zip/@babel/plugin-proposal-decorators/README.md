# @babel/plugin-proposal-decorators

> Compile class and object decorators to ES5

See our website [@babel/plugin-proposal-decorators](https://babeljs.io/docs/en/next/babel-plugin-proposal-decorators.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-proposal-decorators
```

or using yarn:

```sh
yarn add @babel/plugin-proposal-decorators --dev
```
